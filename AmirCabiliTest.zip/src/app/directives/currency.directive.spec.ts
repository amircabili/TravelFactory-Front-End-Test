import { CurrencyDirective } from './currency.directive';

describe('CurrencyDirective', () => {
  it('should create an instance', () => {
    // @ts-ignore
    const directive = new CurrencyDirective();
    expect(directive).toBeTruthy();
  });
});
