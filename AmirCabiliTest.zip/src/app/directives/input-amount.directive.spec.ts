import { InputAmountDirective } from './input-amount.directive';

describe('InputAmountDirective', () => {
  it('should create an instance', () => {
    // @ts-ignore
    const directive = new InputAmountDirective();
    expect(directive).toBeTruthy();
  });
});
