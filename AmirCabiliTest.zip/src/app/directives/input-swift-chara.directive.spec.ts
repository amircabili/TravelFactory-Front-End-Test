import { InputSwiftCharaDirective } from './input-swift-chara.directive';

describe('InputSwiftCharaDirective', () => {
  it('should create an instance', () => {
    // @ts-ignore
    const directive = new InputSwiftCharaDirective();
    expect(directive).toBeTruthy();
  });
});
