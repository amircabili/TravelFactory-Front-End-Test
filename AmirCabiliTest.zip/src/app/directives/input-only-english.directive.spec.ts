import { InputOnlyEnglishDirective } from './input-only-english.directive';

describe('InputOnlyEnglishDirective', () => {
  it('should create an instance', () => {
    // @ts-ignore
    const directive = new InputOnlyEnglishDirective();
    expect(directive).toBeTruthy();
  });
});
