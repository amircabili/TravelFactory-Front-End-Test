export const environment = {
  production: true,
  type: 'prod',
};
