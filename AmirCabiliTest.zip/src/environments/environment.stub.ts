export const environment = {
    production: false,
    type: 'stub',
};
